package com.videoteca.facades;

import com.videoteca.entities.Videos;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class VideosFacade extends AbstractFacade<Videos> {

    @PersistenceContext(unitName = "videotecaPU")
    private EntityManager em;

    public VideosFacade() {
        super(Videos.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<Videos> findAll() {
        return em.createNamedQuery("Videos.findAll", Videos.class).getResultList();
    }

    /**
     * Filtra videos por año de publicación
     */
    public List<Videos> findByAnio(Integer anio) {
        return em.createNamedQuery("Videos.findByAnio", Videos.class)
                 .setParameter("anio", anio)
                 .getResultList();
    }

    /**
     * Filtra videos por tema
     */
    public List<Videos> findByTema(String tema) {
        return em.createNamedQuery("Videos.findByTema", Videos.class)
                 .setParameter("tema", tema)
                 .getResultList();
    }
}
