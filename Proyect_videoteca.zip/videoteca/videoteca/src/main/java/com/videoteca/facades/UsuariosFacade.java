package com.videoteca.facades;

import com.videoteca.entities.Usuarios;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.NoResultException;
import java.util.List;

@Stateless
public class UsuariosFacade extends AbstractFacade<Usuarios> {

    @PersistenceContext(unitName = "videotecaPU")
    private EntityManager em;

    public UsuariosFacade() {
        super(Usuarios.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Busca un usuario por su nombre de usuario y contraseña (login)
     */
    public Usuarios findByUsuarioYContrasena(String usuario, String contrasena) {
        try {
            return em.createNamedQuery("Usuarios.findByUsuarioYContrasena", Usuarios.class)
                    .setParameter("usuario", usuario)
                    .setParameter("contrasena", contrasena)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    /**
     * Verifica si ya existe un usuario con ese nombre de usuario
     */
    public boolean existeUsuario(String usuario) {
        try {
            em.createNamedQuery("Usuarios.findByUsuario", Usuarios.class)
              .setParameter("usuario", usuario)
              .getSingleResult();
            return true;
        } catch (NoResultException e) {
            return false;
        }
    }

    @Override
    public List<Usuarios> findAll() {
        return em.createNamedQuery("Usuarios.findAll", Usuarios.class).getResultList();
    }
}
