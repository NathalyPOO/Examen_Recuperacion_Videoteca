package com.videoteca.entities;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "videos")
@NamedQueries({
    @NamedQuery(name = "Videos.findAll", query = "SELECT v FROM Videos v"),
    @NamedQuery(name = "Videos.findByTema",
                query = "SELECT v FROM Videos v WHERE v.tema = :tema"),
    @NamedQuery(name = "Videos.findByAnio",
                query = "SELECT v FROM Videos v WHERE v.anio = :anio")
})
public class Videos implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "titulo", nullable = false, length = 200)
    private String titulo;

    @Column(name = "autor", nullable = false, length = 100)
    private String autor;

    @Column(name = "anio", nullable = false)
    private Integer anio;

    @Column(name = "tema", nullable = false, length = 100)
    private String tema;

    @Column(name = "url", nullable = false, length = 500)
    private String url;

    @Column(name = "imagen_preview", length = 500)
    private String imagenPreview;

    public Videos() {}

    public Videos(Integer id) {
        this.id = id;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public Integer getAnio() { return anio; }
    public void setAnio(Integer anio) { this.anio = anio; }

    public String getTema() { return tema; }
    public void setTema(String tema) { this.tema = tema; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getImagenPreview() { return imagenPreview; }
    public void setImagenPreview(String imagenPreview) { this.imagenPreview = imagenPreview; }

    @Override
    public String toString() {
        return "Videos{id=" + id + ", titulo=" + titulo + "}";
    }
}
